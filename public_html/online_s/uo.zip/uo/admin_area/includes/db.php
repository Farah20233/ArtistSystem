<?php

$con = mysqli_connect("localhost","root","","updated_ecom_store");

?>